<?php

class Shop_model extends MY_Model {
  
    const DB_TABLE = 'shop';
    const DB_TABLE_PK = 'id';
    
    public $id;
    public $name;
    
}

?>